import Funciones

logo_MZBanks = """
 /$$      /$$ /$$$$$$$$     /$$$$$$$                      /$$                
| $$$    /$$$|_____ $$     | $$__  $$                    | $$                
| $$$$  /$$$$     /$$/     | $$  \ $$  /$$$$$$  /$$$$$$$ | $$   /$$  /$$$$$$$
| $$ $$/$$ $$    /$$/      | $$$$$$$  |____  $$| $$__  $$| $$  /$$/ /$$_____/
| $$  $$$| $$   /$$/       | $$__  $$  /$$$$$$$| $$  \ $$| $$$$$$/ |  $$$$$$ 
| $$\  $ | $$  /$$/        | $$  \ $$ /$$__  $$| $$  | $$| $$_  $$  \____  $$
| $$ \/  | $$ /$$$$$$$$ /$$| $$$$$$$/|  $$$$$$$| $$  | $$| $$ \  $$ /$$$$$$$/
|__/     |__/|________/|__/|_______/  \_______/|__/  |__/|__/  \__/|_______/ 
                                                                             
"""
print(logo_MZBanks)

dic_usuarios = dict()
dic_items_prestados = dict()
dic_items_en_inventario = dict() 
dic_prestamos_registrados = dict()     
dic_devoluciones_registradas = dict()  
dic_ventas_registradas = dict()
dic_admins = { "Julian_admin": "clave123", "Marypzm": "MZ.banks2026", "Carolina": "Clave456"}

def MostrarMenu():
    menu = """
    1. Registrar Usuario
    2. Registrar Prestamo
    3. Registrar devolucion
    4. Consultar items con mas de 30 dias
    5. Consultar articulo prestado
    6. Administrador 
    7. Salir
    """
    return menu

Espa = 60
titulo = 'MZ.Banks'
Opciones_Val = ['1', '2', '3', '4', '5', '6', '7']

while True:
    print(('-' * Espa))
    print(titulo.center(Espa))
    print('')
    print('..::Bienvenidos::..'.center(Espa))
    print(('-' * Espa))
    print(MostrarMenu())
    
    opcion = input('Favor registrar la opcion deseada--> ')
    
    if opcion in Opciones_Val:
        match opcion:
            case '1':
                print('\tRegistrar Usuario')
                Nombre = input("Ingrese nombre completo: ")
                if Funciones.ValidarNombreApellido(Nombre):
                    Cedula = input("Ingrese numero de cedula: ")
                    if Funciones.ValidarCedula(Cedula):
                        Cedula = int(Cedula)                        
                        if Cedula in dic_usuarios:
                            print("Error, este usuario ya esta registrado.\n")
                        else:                    
                            Correo = input("Ingrese su correo: ")                           
                            if Funciones.validar_correo(Correo):
                                Tiempo_de_prestamo = int(input("Ingrese el tiempo de prestamo deseado (5, 10, 15 o 30): "))
                                
                                if Funciones.ValidarTiempoPrestamo(Tiempo_de_prestamo):
                                    print(Nombre, Cedula, Correo, Tiempo_de_prestamo)
                                    print("Su usuario ha sido registrado correctamente.")                                   
                                    
                                    dic_usuarios = Funciones.registro_de_usuario(Nombre, Cedula, Correo, Tiempo_de_prestamo, dic_usuarios)                                    
                                else:
                                    print("Esas opciones de tiempo no son validas")
                            else:
                                print("El correo es invalido")    
                    else:
                        print("El numero de cedula es invalido")
                else:
                    print("El nombre es invalido")
                
            case '2':                
                print('\tRegistrar Prestamo')               
                Cedula = int(input("Ingrese su numero de cedula: "))
                
                if Cedula in dic_usuarios:
                    print("Verificacion de usuario correcta\n")

                    proceder_al_prestamo = False

                    if len(dic_items_en_inventario) == 0:
                        print("No hay ítems en el inventario.")
                        respuesta = input("¿Desea registrar nuevos items? (si/no): ").strip().lower()
                        
                        if respuesta == "si":
                            print("\n   Registrar Items")

                            dic_items_en_inventario = Funciones.registrar_item(dic_items_en_inventario, dic_items_prestados)

                            print("Ha finalizado el registro de ítems.")
                            respuesta_prestamo = input("¿Desea seguir con el registro del préstamo? (si/no): ").strip().lower()
                            
                            if respuesta_prestamo == "si":
                                proceder_al_prestamo = True
                            else:
                                print("Cancelando operación y regresando al menú principal...\n")
                        else:
                            print("Regresando al menú principal...\n")

                    else:
                        print("El inventario cuenta con ítems disponibles.")
                        decision = input("¿Desea registrar un nuevo ítem antes de continuar? (si/no): ").strip().lower()
                        
                        if decision == "si":
                            print("\n   Registrar items")
                            dic_items_en_inventario = Funciones.registrar_item(dic_items_en_inventario, dic_items_prestados)

                            print("Ha finalizado el registro de ítems.")
                            respuesta_prestamo = input("¿Desea seguir con el registro del préstamo? (si/no): ").strip().lower()
                            
                            if respuesta_prestamo == "si":
                                proceder_al_prestamo = True
                            else:
                                print("Cancelando operación y regresando al menú principal...\n")
                        
                        elif decision == "no":

                            proceder_al_prestamo = True

                    if proceder_al_prestamo:
                        print("\n  Ítems disponibles  ")
                        for clave, datos in dic_items_en_inventario.items():
                            print(f"ID: {clave} | Nombre: {datos[0]} | Categoría: {datos[1]} | Estado: {datos[3]}")
                        print("-" * 60 + "\n")
                        
                        id_item = input("Ingrese el ID del ítem que desea prestar: ").strip()
                        
                        resultado = Funciones.registrar_prestamo(id_item, Cedula, dic_items_en_inventario, dic_items_prestados)
                        
                        if resultado == "prestado":
                            print("Error, este ítem ya se encuentra prestado.")
                        elif resultado == "no_existe":
                            print("Error, El ID ingresado no corresponde a ningún ítem.")
                        else:
                            dic_items_en_inventario, dic_items_prestados = resultado
                            print("El prestamo se realizo con exito\n")
                            datos_item = dic_items_prestados[id_item][0]
                            Funciones.almacenar_prestamo_registrado(dic_prestamos_registrados, id_item, datos_item, Cedula)
                else:     
                    print("Usuario no registrado.\n")
            case '3':
                print('\tRegistrar devolucion')
                Cedula = int(input("Ingrese su numero de cedula: "))
                
                if Cedula in dic_usuarios:
                    print("Verificacion de usuario correcta")
                    id_item = input("Ingrese el ID o código del ítem a devolver: ")

                    resultado = Funciones.registrar_devolucion_o_venta(id_item, Cedula, dic_items_en_inventario, dic_items_prestados, dic_usuarios)
                    dic_items_en_inventario, dic_items_prestados, archivo_generado, tipo_accion, cobro = resultado

                    if tipo_accion == "no_prestado":
                        print("Error, este ítem no ha sido prestado.\n")

                    elif tipo_accion == "usuario_incorrecto":
                        print("Error, este ususario no ha realizado el prestamo.\n")
                
                    elif tipo_accion == "venta":
                        print("Tiempo limite excedido")
                        print(f"Monto a pagar: ${cobro}")
                        print(f"Se generó la factura: {archivo_generado}\n")
                        Funciones.almacenar_venta_registrada(dic_ventas_registradas, id_item, Cedula, cobro)
                
                    elif tipo_accion == "devolucion":
                        print("la devolucion se registro con exito")
                        print(f"Se ha generado el certificado: {archivo_generado}\n")
                        datos_item = dic_items_en_inventario[id_item] 
                        Funciones.almacenar_devolucion_registrada(dic_devoluciones_registradas, id_item, datos_item, Cedula)
            
                else: 
                    print("Usuario no registrado.")
            case '4':
                print('\tConsultar items con mas de 30 dias')
                Cedula = int(input("Ingrese su numero de cedula: "))
                
                if Cedula in dic_usuarios:
                    print("Verificacion de usuario correcta\n")
                
                    if len(dic_items_prestados) == 0:
                        print("No se ha realizado ningun prestamo\n")
                        
                    else:
                        Funciones.consultar_prestamos_vencidos(dic_items_prestados, dic_usuarios)
                else: 
                    print("Usuario no registrado.")
            case '5':
                print('\tConsultar articulo prestado')
                Cedula = int(input("Ingrese su numero de cedula: "))
                
                if Cedula in dic_usuarios:
                    print("Verificacion de usuario correcta")
                    Funciones.generar_y_leer_estadisticas_prestamos(dic_items_prestados, dic_usuarios)
                    print("se ha generado estadistica.texto")
                else: 
                    print("Usuario no registrado.")
            case '6':
                print('\tAdministrador')
                
                dic_admins = {
                    "Julian_admin": "clave123",
                    "Marypzm": "MZ.banks2026",
                    "supervisor": "09876",
                    "gerente": "Llave678",
                    "Carolina": "Clave456"
                }
                
                print("\tACCESO RESTRINGIDO")
                usuario_admin = input("Ingrese su usuario de administrador: ")
                contraseña= input("Ingrese su contraseña: ")
                
                if usuario_admin in dic_admins and dic_admins[usuario_admin] == contraseña:
                    print(f"\nAcceso concedido, Bienvenido(a) {usuario_admin}.\n")
                    
                    def Mostrar_SubMenu():
                        Submenu = """
    1. Total de préstamos registrados
    2. Total de ítems devueltos
    3. Total de ventas realizadas
    4. Total pago realizado
    5. Lista de usuarios
    6. Usuario con mayor y menor cantidad de préstamos.
    7. Salir
                        """
                        return Submenu
                
                    Espa = 60
                    titulo = 'MZ.Banks'
                    Opciones_Val = ['1', '2', '3', '4', '5', '6', '7']
                
                    while True:
                        print(('-' * Espa))
                        print(titulo.center(Espa))
                        print('')
                        print('..::Bienvenidos al Menu de administradores::..'.center(Espa))
                        print(('-' * Espa))
                        print(Mostrar_SubMenu())
                        
                        opcion = input('Favor registrar la opcion deseada--> ')
                
                        match opcion:
                            case '1':
                                print("\tTotal de préstamos registrados")
                                Funciones.reporte_total_prestamos1(dic_prestamos_registrados)
                                                            
                            case '2':
                                print("\tTotal de ítems devueltos")
                                Funciones.reporte_total_devoluciones2(dic_devoluciones_registradas)
                            
                            case '3':
                                print("\tTotal de ventas realizadas")
                                Funciones.reporte_total_ventas3(dic_ventas_registradas)
                            
                            case '4':
                                print("\tTotal pago realizado")
                                Funciones.reporte_total_pago_realizado4(dic_ventas_registradas)
                            
                            case '5':
                                print("\tLista de usuarios")
                                Funciones.mostrar_lista_usuarios5(dic_usuarios)                                
                                
                            case '6':
                                print("\tUsuario con mayor y menor cantidad de préstamos.")
                                Funciones.reporte_usuario_mayor_menor_prestamos6(dic_items_prestados, dic_usuarios)
                            
                            case '7':
                                print("Cerrando sesión de administración...")
                                print("Regresando al menú principal \n")
                                break 
                            
                            case _:
                                print("Error, Opción inválida. Intente de nuevo.\n")
                
                else:
                    print("Error, Usuario o contraseña incorrectos, acceso denegado.\n")
            case '7':
                print('Gracias por usar MZ:Banks')
                break 
    else:
        error = 'Opcion invalida, vuelva a intentarlo'
        print(error) 