from datetime import datetime
def ValidarNombreApellido(nombre:str)->bool:
    
    longitud = len(nombre)
    if longitud >= 3:
        
        numeros = '0123456789'
        for letra in nombre:
            if letra in numeros:
                return False
        return True
    else:
        return False

def ValidarCedula(cedula:str)->bool:
    longitud = len(cedula)
    if longitud >= 3 and longitud <= 15:
        #puedo validar que todos sean digitos
        if cedula.isnumeric():
            return True
        else:
            return False
    else:
        return False
    
def validar_correo(correo):
    largo = len(correo)
    
    if largo < 7:
        return False

    if correo[largo-4] != '.' or correo[largo-3] != 'c' or correo[largo-2] != 'o' or correo[largo-1] != 'm':
        return False

    cantidad_arrobas = 0
    posicion_arroba = -1
    
    for i in range(largo):
        if correo[i] == '@':
            cantidad_arrobas = cantidad_arrobas + 1
            posicion_arroba = i 

    if cantidad_arrobas != 1:
        return False

    if posicion_arroba == 0 or posicion_arroba >= largo - 5:
        return False
    permitidos = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-"
    
    for i in range(largo):
       
        if correo[i] == '@':
            continue
            
        if correo[i] not in permitidos:
            return False

    return True

def ValidarTiempoPrestamo(dias)->bool:
    if isinstance(dias, int):
        valores_permitidos = [5, 10, 15, 30]
        if dias in valores_permitidos:
            return True
        else:
            return False
    else:
        return False
    
def registro_de_usuario(nombre: str, cedula:int, correo: str, tiempo_de_prestamo, dic_usuario: dict):
    list_usuario =[nombre, int(cedula), correo, tiempo_de_prestamo ]
    dic_usuario[cedula]= list_usuario
    return dic_usuario

def ValidarNombreIntem(nombre:str)->bool: #
 
    longitud = len(nombre)
    if longitud >= 3:
        return True
    else:
        return False
    

def registrar_item(dic_items_en_inventario: dict, dic_items_prestados: dict):
    while True:

        while True:
            nombre_item = input("Introduce el nombre del ítem: ")
            if len(nombre_item) >= 3:
                break
            else:
                print("Error: El nombre debe tener al menos 3 letras o números")

        categorias_validas = ["Videojuegos", "Libros", "Musica y video", "Herramientas", "Dinero", "Miscelaneo y varios"]
        while True:
            print("\n--- Categorías Disponibles ---")
            print("1. Videojuegos\n2. Libros\n3. Musica y video\n4. Herramientas\n5. Dinero\n6. Miscelaneo y varios\n")
            opcion_cat = input("Seleccione el número de la categoría deseada (1-6): ")
            if opcion_cat in ["1", "2", "3", "4", "5", "6"]:
                indice = int(opcion_cat) - 1
                categoria = categorias_validas[indice]
                break
            else:
                print("Error: Opción no válida.\n")

        numero_unico = 1
        id_item = categoria + "-" + str(numero_unico)

        while id_item in dic_items_en_inventario or id_item in dic_items_prestados:
            numero_unico += 1
            id_item = categoria + "-" + str(numero_unico)

        precio = float(input("Introduce el precio de compra del ítem: "))

        while True:
            nota_estado = float(input("Valoración del estado (1.0 a 10.0): "))
            if 1.0 <= nota_estado <= 10.0:
                if nota_estado >= 8.5: estado_final = "Como nuevo"
                elif nota_estado >= 6.0: estado_final = "Bueno pero con desgaste"
                elif nota_estado >= 4.0: estado_final = "Regular, requiere mantenimiento"
                else: estado_final = "En mal estado"
                break
            else:
                print("Error: Valoración inválida.")

        datos_item = [nombre_item, categoria, precio, estado_final]
        dic_items_en_inventario[id_item] = datos_item
        
        print(f"Ítem registrado con éxito. ID generado: {id_item}\n")
        
        continuar = input("¿Desea registrar otro ítem? (si/no): ").strip().lower()
        if continuar != "si":
            break
            
    return dic_items_en_inventario


def registrar_prestamo(id_item: str, cedula: int, dic_items_en_inventario: dict, dic_items_prestados: dict):

    if id_item in dic_items_prestados:
        return "prestado"

    elif id_item in dic_items_en_inventario:
        datos_item = dic_items_en_inventario[id_item]  
        fecha_prestamo = datetime.now().date() 

        dic_items_prestados[id_item] = [datos_item, cedula, fecha_prestamo]
     
        del dic_items_en_inventario[id_item]
        
        return dic_items_en_inventario, dic_items_prestados

    else:
        return "no_existe"
    
    
def registrar_devolucion_o_venta(id_item: str, cedula: int, dic_items_en_inventario: dict, dic_items_prestados: dict, dic_usuarios: dict):
    
    if id_item in dic_items_prestados:
        datos_prestamo = dic_items_prestados[id_item]
        datos_item = datos_prestamo[0]
        cedula_usuario = datos_prestamo[1] 
        fecha_prestamo = datos_prestamo[2]

        if cedula != cedula_usuario:

            return dic_items_en_inventario, dic_items_prestados, "", "usuario_incorrecto", 0

        datos_usuario = dic_usuarios[cedula_usuario]
        nombre_usuario = datos_usuario[0]
        
        fecha_hoy = datetime.now().date()
        dias_transcurridos = (fecha_hoy - fecha_prestamo).days
        nombre_limpio = nombre_usuario.replace(" ", "_")
           
        if dias_transcurridos > 30:
            precio_base = datos_item[2]
            impuesto_conchudez = precio_base * 0.23
            total_pagar = precio_base + impuesto_conchudez
                
            del dic_items_prestados[id_item]            
         
            nombre_archivo = f"{nombre_limpio}_{id_item}.txt"
            archivo = open(nombre_archivo, "w")
            archivo.write("-" * 60 + "\n")
            archivo.write("MZ.BANKS".center(60) + "\n")
            archivo.write("-" * 60 + "\n")
            archivo.write(f"Motivo: El prestamo supero los 30 dias ({dias_transcurridos} dias).\n")
            archivo.write(f"ID del Articulo: {id_item}\n")
            archivo.write(f"Descripcion: {datos_item[0]}\n")
            archivo.write(f"Comprador: {nombre_usuario} (Cedula: {cedula_usuario})\n")
            archivo.write("-" * 60 + "\n")
            archivo.write(f"Subtotal (Valor Base): ${precio_base}\n")
            archivo.write(f"Impuesto por Conchudez (23%): ${impuesto_conchudez}\n")
            archivo.write(f"TOTAL A PAGAR: ${total_pagar}\n")
            archivo.write("-" * 60 + "\n")
            archivo.close()
            
 
            return dic_items_en_inventario, dic_items_prestados, nombre_archivo, "venta", total_pagar      

        else:
            print(f"\n Tiempo válido. Días con el ítem: {dias_transcurridos} días.")
            print("--- Evaluacion de Estado en Devolucion ---")
            while True:
                print("Valore el estado en que regresa el item (Nota de 1.0 a 10.0):")
                nota_estado = float(input("Estado numérico: "))
                
                if 1.0 <= nota_estado <= 10.0:
                    if nota_estado >= 9.0:
                        estado_devolucion = "Como nuevo"
                    elif nota_estado >= 6.0:
                        estado_devolucion = "Bueno pero con desgaste"
                    elif nota_estado >= 4.0:
                        estado_devolucion = "Regular, requiere mantenimiento"
                    else:
                        estado_devolucion = "En mal estado"
                    break
                else:
                    print("Error: La valoración debe ser entre 1.0 y 10.0.\n")

        
            datos_item[3] = estado_devolucion
            dic_items_en_inventario[id_item] = datos_item
            del dic_items_prestados[id_item]

     
            nombre_archivo = f"{nombre_limpio}_{fecha_hoy}_{id_item}.txt"
            archivo = open(nombre_archivo, "w")
            archivo.write("-" * 60 + "\n")
            archivo.write("CERTIFICADO DE DEVOLUCIÓN".center(60) + "\n")
            archivo.write("MZ.Banks".center(60) + "\n")
            archivo.write("-" * 60 + "\n")
            archivo.write(f"ID del Item: {id_item}\n")
            archivo.write(f"Descripción: {datos_item[0]}\n")
            archivo.write(f"Prestador: {nombre_usuario}\n")
            archivo.write(f"Fecha de Préstamo: {fecha_prestamo}\n")
            archivo.write(f"Fecha de Devolución: {fecha_hoy}\n")
            archivo.write("-" * 60 + "\n")
            archivo.write(f"Condiciones de entrega: {estado_devolucion}\n")
            archivo.write("-" * 60 + "\n")
            archivo.close()
            
            
            return dic_items_en_inventario, dic_items_prestados, nombre_archivo, "devolucion", 0
            
    else:
            return dic_items_en_inventario, dic_items_prestados, "", "no_prestado", 0
    
def consultar_prestamos_vencidos(dic_items_prestados: dict, dic_usuarios: dict):
    
    fecha_hoy = datetime.now().date()
    contador_vencidos = 0
    
    for id_item in dic_items_prestados:
        datos_prestamo = dic_items_prestados[id_item]
        datos_item = datos_prestamo[0]
        cedula_usuario = datos_prestamo[1]
        fecha_prestamo = datos_prestamo[2]

        dias_transcurridos = (fecha_hoy - fecha_prestamo).days
        
        if dias_transcurridos > 30:
            contador_vencidos += 1
            nombre_item = datos_item[0]
            nombre_usuario = dic_usuarios[cedula_usuario][0] 
            print(f" {contador_vencidos}")
            print(f"   ID Artículo: {id_item}")
            print(f"   Descripción: {nombre_item}")
            print(f"   Prestado a : {nombre_usuario} (Cédula: {cedula_usuario})")
            print(f"   Días de retraso: {dias_transcurridos} días")

    if contador_vencidos == 0:
        print(" No hay artículos prestados con retraso.\n")
    else:
        print(f"Total de alertas críticas encontradas: {contador_vencidos}\n")


def generar_y_leer_estadisticas_prestamos(dic_items_prestados: dict, dic_usuarios: dict):
    fecha_hoy = datetime.now().date()
    lista_prestamos = []

    for id_item in dic_items_prestados:
        datos_prestamo = dic_items_prestados[id_item]
        datos_item = datos_prestamo[0]     
        cedula_usuario = datos_prestamo[1]  
        fecha_prestamo = datos_prestamo[2]  

        dias = (fecha_hoy - fecha_prestamo).days
        nombre_usuario = dic_usuarios[cedula_usuario][0] 
        descripcion_item = datos_item[0]                 

        lista_prestamos.append([dias, id_item, descripcion_item, nombre_usuario])

    lista_ordenada = sorted(lista_prestamos, reverse=True)

    nombre_archivo = "estadisticas_prestamos.txt"

    with open(nombre_archivo, "w", encoding="utf-8") as archivo_escritura:
        archivo_escritura.write("-" * 60 + "\n")
        archivo_escritura.write("ESTADÍSTICAS GENERALES: TIEMPO DE PRÉSTAMO POR ÍTEM".center(60) + "\n")
        archivo_escritura.write("-" * 60 + "\n\n")
        
        if len(lista_ordenada) == 0:
            archivo_escritura.write("No hay préstamos activos registrados actualmente en el sistema.\n")
        else:
            puesto = 1
            for prestamo in lista_ordenada:
                dias = prestamo[0]
                id_item = prestamo[1]
                desc = prestamo[2] 
                usuario = prestamo[3]
                
                archivo_escritura.write(f"Ítem Nº {puesto}\n")
                archivo_escritura.write(f"  Tiempo del préstamo: {dias} días\n")
                archivo_escritura.write(f"  ID Artículo: {id_item} ({desc})\n")
                archivo_escritura.write(f"  Usuario asignado: {usuario}\n")
                archivo_escritura.write("-" * 40 + "\n")
                puesto += 1



def almacenar_prestamo_registrado(dic_prestamos_registrados: dict, id_item: str, datos_item: list, cedula: int):
    """Guarda el historial directamente en tu diccionario de préstamos."""
    id_transaccion = len(dic_prestamos_registrados) + 1
    fecha_hoy = datetime.now().date()
    
    dic_prestamos_registrados[id_transaccion] = {
        "id_item": id_item,
        "nombre_item": datos_item[0],       
        "categoria": datos_item[1],         
        "precio_compra": datos_item[2],     
        "estado_entrega": datos_item[3],    
        "cedula_usuario": cedula,  
        "fecha_prestamo": fecha_hoy         
    }
    return dic_prestamos_registrados

def almacenar_devolucion_registrada(dic_devoluciones_registradas: dict, id_item: str, datos_item: list, cedula: int):
    """Guarda el historial directamente en tu diccionario de devoluciones."""
    id_devolucion = len(dic_devoluciones_registradas) + 1
    fecha_hoy = datetime.now().date()
    
    dic_devoluciones_registradas[id_devolucion] = {
        "id_item": id_item,
        "nombre_item": datos_item[0],       
        "categoria": datos_item[1],         
        "precio_compra": datos_item[2],     
        "estado_recibido": datos_item[3],    
        "cedula_usuario": cedula,  
        "fecha_devolucion": fecha_hoy       
    }
    return dic_devoluciones_registradas

def almacenar_venta_registrada(dic_ventas_registradas: dict, id_item: str, cedula: int, total_pagado: float):
    """Guarda el historial directamente en tu diccionario de ventas."""
    id_venta = len(dic_ventas_registradas) + 1
    fecha_hoy = datetime.now().date()
    
    dic_ventas_registradas[id_venta] = {
        "id_item": id_item,
        "cedula_comprador": cedula,  
        "fecha_venta": fecha_hoy,           
        "monto_total_pagado": total_pagado  
    }
    return dic_ventas_registradas


def reporte_total_prestamos1(dic_prestamos_registrados: dict):

    print("\n" + "-" * 60)
    print("REPORTE TOTAL DE PRÉSTAMOS REGISTRADOS".center(60))
    print("-" * 60)
    
    if len(dic_prestamos_registrados) == 0:
        print("No se ha registrado ningún préstamo en el sistema todavía.\n")
    else:
        print(f"Cantidad total de préstamos registrados: {len(dic_prestamos_registrados)}\n")
        print("-" * 60)

        contador = 1
        
        for id_transaccion, datos in dic_prestamos_registrados.items():
            id_item = datos["id_item"]
            nombre_item = datos["nombre_item"]
            cedula = datos["cedula_usuario"]
            fecha = str(datos["fecha_prestamo"])

            print(f"{contador}. Transacción Nº: {id_transaccion}")
            print(f"   - ID Ítem: {id_item}")
            print(f"   - Descripción: {nombre_item}")
            print(f"   - Cédula Usuario: {cedula}")
            print(f"   - Fecha de Préstamo: {fecha}")
            print("-" * 60) 
            
            contador += 1
            
    print("-" * 60 + "\n")
    
def reporte_total_devoluciones2(dic_devoluciones_registradas: dict):
    

    print("\n" + "-" * 60)
    print("REPORTE TOTAL DE ÍTEMS DEVUELTOS".center(60))
    print("-" * 60)
    
    if len(dic_devoluciones_registradas) == 0:
        print("No se ha registrado ninguna devolución en el sistema todavía.\n")
    else:
        print(f"Cantidad total de ítems devueltos: {len(dic_devoluciones_registradas)}\n")
        print("-" * 60)

        contador = 1
        
        for id_devolucion, datos in dic_devoluciones_registradas.items():
            id_item = datos["id_item"]
            nombre_item = datos["nombre_item"]
            cedula = datos["cedula_usuario"]
            estado_recibido = datos["estado_recibido"]

            print(f"{contador}. Devolución Nº: {id_devolucion}")
            print(f"   - ID Ítem: {id_item}")
            print(f"   - Descripción: {nombre_item}")
            print(f"   - Cédula Usuario: {cedula}")
            print(f"   - Estado Recibido: {estado_recibido}")
            print("-" * 60)
            
            contador += 1
            
    print("-" * 60 + "\n")
    
def reporte_total_ventas3(dic_ventas_registradas: dict):
  
    print("\n" + "-" * 60)
    print("REPORTE TOTAL DE VENTAS REALIZADAS".center(60))
    print("-" * 60)
    
    if len(dic_ventas_registradas) == 0:
        print("No se ha registrado ninguna venta en el sistema todavía.\n")
    else:
        print(f"Cantidad de ventas (multas): {len(dic_ventas_registradas)}\n")
        print("-" * 60)

        contador = 1

        for id_venta, datos in dic_ventas_registradas.items():
            id_item = datos["id_item"]
            cedula = datos["cedula_comprador"]
            fecha = str(datos["fecha_venta"])

            monto = f"${datos['monto_total_pagado']:.2f}" 

            print(f"{contador}. Venta Nº: {id_venta}")
            print(f"   - ID Ítem: {id_item}")
            print(f"   - Cédula Comprador: {cedula}")
            print(f"   - Fecha de Venta: {fecha}")
            print(f"   - Monto Total Pagado: {monto}")
            print("-" * 60)
            
            contador += 1
            
    print("-" * 60 + "\n")

def reporte_total_pago_realizado4(dic_ventas_registradas: dict):

    print("\n" + "-" *60)
    print("REPORTE TOTAL PAGO REALIZADO (INGRESOS)".center(60))
    print("-" *60)

    total_recaudado = 0.0

    for datos in dic_ventas_registradas.values():
        total_recaudado += datos["monto_total_pagado"]

    if len(dic_ventas_registradas) == 0:
        print("No se registran ingresos monetarios en el sistema todavía.\n")
        print(f"Caja Actual: ${0.00:.2f}".center(60))
    else:
        print(f"Total de transacciones que generaron ingresos: {len(dic_ventas_registradas)}")
        print("-" *60)
        
        texto_dinero = f"TOTAL RECAUDADO EN CAJA: ${total_recaudado:.2f}"
        print(texto_dinero.center(60))
        
    print("-" *60 + "\n")

def mostrar_lista_usuarios5(dic_usuarios: dict):
    print("\n" + "-" * 60)
    print("LISTA DE USUARIOS REGISTRADOS".center(60))
    print("-" * 60)
    
    if len(dic_usuarios) == 0:
        print("No hay usuarios registrados en el sistema todavía.\n")
    else:
        print(f"Total de usuarios registrados: {len(dic_usuarios)}\n")
        print("-" * 60)

        contador = 1
        
        for cedula, datos in dic_usuarios.items():
            nombre = datos[0]
            correo = datos[2]  
            tiempo_prestamo = datos[3] 

            print(f"{contador}. Usuario: {nombre}")
            print(f"   - Cédula: {cedula}")
            print(f"   - Correo: {correo}")
            print(f"   - Tiempo de Préstamo: {tiempo_prestamo} días")
            print("-" * 60)
            
            contador += 1
            
    print("-" * 60 + "\n")
    
def reporte_usuario_mayor_menor_prestamos6(dic_items_prestados: dict, dic_usuarios: dict):

    print("\n" + "-" * 60)
    print("REPORTE: RÉCORD DE PRÉSTAMOS ACTIVOS".center(60))
    print("-" * 60)

    if len(dic_items_prestados) == 0:
        print("No se registran préstamos activos en el sistema.\n")
    else:
        conteo_activos = {}
        for datos_prestamo in dic_items_prestados.values():
            cedula = datos_prestamo[1]
            
            if cedula in conteo_activos:
                conteo_activos[cedula] += 1
            else:
                conteo_activos[cedula] = 1

        max_prestamos = max(conteo_activos.values())
        min_prestamos = min(conteo_activos.values())
        
        usuarios_max = []
        usuarios_min = []

        for cedula, cantidad in conteo_activos.items():
            if cedula in dic_usuarios:
                nombre = dic_usuarios[cedula][0]
            else:
                nombre = "Usuario No Registrado"
                
            info_usuario = f"{nombre} (Cédula: {cedula}) con {cantidad} préstamo(s)."
            
            if cantidad == max_prestamos:
                usuarios_max.append(info_usuario)
            if cantidad == min_prestamos:
                usuarios_min.append(info_usuario)

        if max_prestamos == min_prestamos:
            print(f"Todos los usuarios activos tienen la misma cantidad de préstamos ({max_prestamos}):")
            for user in usuarios_max:
                print(f"-> {user}")
                

        else:
            print("Usuario(s) con mayor cantidad de préstamos activos:")
            for user in usuarios_max:
                print(f"-> {user}")
            print()
                
            print("Usuario(s) con menor cantidad de préstamos activos:")
            for user in usuarios_min:
                print(f"-> {user}")
            
    print("-" * 60 + "\n")